5000 - Identity service public endpoint
8004 - Orchestration (heat) endpoint
8774 - Compute (nova) endpoints
9292 - Image service (glance) API